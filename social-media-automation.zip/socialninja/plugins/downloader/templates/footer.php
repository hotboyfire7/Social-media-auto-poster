<?php
/**
 * @package Social Ninja
 * @version 1.0
 * @author InspiredDev <iamrock68@gmail.com>
 * @copyright 2015
 */
if(!defined('S_NINJA'))exit();
?>

<?php include(__ROOTDIR__.'/templates/import_modal.php')?>
<script src="js/custom.js?v=1.3"></script>