<div class="row">
	<div class="col-lg-12">
    	<h3 class="text-center"><?php echo $lang['editor']['index']['title1']?></h3><br/><br/>
        <div class="text-center">
        	<a class="btn btn-success" href="<?php echo makeuri('plugins/media/editor.php')?>"><i class="glyphicon glyphicon-camera"></i>&nbsp;&nbsp;<?php echo $lang['editor']['index']['imgvd']?></a>&nbsp;&nbsp;
            <a class="btn btn-info" href="<?php echo makeuri('plugins/media/meme.php')?>"><i class="glyphicon glyphicon-picture"></i>&nbsp;&nbsp;<?php echo $lang['editor']['index']['meme']?></a>&nbsp;&nbsp;
            <a class="btn btn-danger" href="<?php echo makeuri('plugins/media/htoimage.php')?>"><i class="glyphicon glyphicon-picture"></i>&nbsp;&nbsp;<?php echo $lang['editor']['index']['htoi']?></a>&nbsp;&nbsp;<br/><br/>
            <a class="btn btn-primary" href="<?php echo makeuri('plugins/media/tools.php')?>"><i class="glyphicon glyphicon-wrench"></i>&nbsp;&nbsp;<?php echo $lang['editor']['index']['wmview']?></a>&nbsp;&nbsp;
            <a class="btn btn-default" href="<?php echo makeuri('plugins/media/tools.php')?>"><i class="glyphicon glyphicon-picture"></i>&nbsp;&nbsp;<?php echo $lang['editor']['index']['twm']?></a>&nbsp;&nbsp;
            <a class="btn btn-success" href="<?php echo makeuri('plugins/media/tools.php')?>"><i class="glyphicon glyphicon-list-alt"></i>&nbsp;&nbsp;<?php echo $lang['editor']['index']['slf']?></a>&nbsp;&nbsp;
        </div>
        <br/><br/>
        <h3 class="text-center"><?php echo $lang['editor']['index']['vdwn']?></h3><br/><br/>
        <div class="text-center">
        	<a class="btn btn-success" href="<?php echo makeuri('plugins/downloader/index.php')?>"><i class="glyphicon glyphicon-film"></i>&nbsp;&nbsp;<?php echo $lang['editor']['index']['ivdwn']?></a>&nbsp;&nbsp;
            <a class="btn btn-info" href="<?php echo makeuri('plugins/media/videos.php')?>"><i class="glyphicon glyphicon-adjust"></i>&nbsp;&nbsp;<?php echo $lang['editor']['index']['eqv']?></a>&nbsp;&nbsp;
        </div>
    </div>
</div>