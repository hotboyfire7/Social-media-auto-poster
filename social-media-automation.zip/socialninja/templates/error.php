<?php
/**
 * @package Social Ninja
 * @version 1.0
 * @author InspiredDev <iamrock68@gmail.com>
 * @copyright 2015
 */
if(!defined('S_NINJA'))exit();
?>

<div class="row">
	<div class="col-lg-12">
    	<div class="alert alert-danger">
        	<i class="glyphicon glyphicon-remove"></i>&nbsp;&nbsp;<?php echo $message?>
        </div>
    </div>
</div>