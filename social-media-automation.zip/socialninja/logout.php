<?php
/**
 * @package Social Ninja
 * @version 1.0
 * @author InspiredDev <iamrock68@gmail.com>
 * @copyright 2015
 */

include(dirname(__FILE__).'/loader.php');
$_SESSION = array();
redirect('index.php');
?>